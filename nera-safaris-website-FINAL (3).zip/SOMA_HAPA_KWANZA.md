# Nera Safaris — Maelekezo ya Kuweka Tovuti Live (Toleo Jipya)

Karibu! Hii ni toleo jipya la tovuti yako, ambalo limerekebisha tatizo kubwa lililokuwepo kwenye toleo la awali.

## Nini kilibadilika (na kwa nini)

Toleo la awali lilikuwa na kurasa zote (Home, About, Packages n.k.) ndani ya faili MOJA tu (`index.html`), na JavaScript ndiyo iliyokuwa "inatengeneza" kila ukurasa pale mtu anabofya link. Tatizo: ukifungua link ya moja kwa moja kwa mfano `nerasafaris.com/packages.html` (kutoka Google, WhatsApp, au bookmark), hosting yako ingeonyesha **404 error** kwa sababu faili hilo halikuwepo kihalisia — ni kama "chumba" kilichokuwepo tu kwenye kumbukumbu ya JS, si mlangoni.

Sasa kila ukurasa ni **faili halisi tofauti** (`packages.html`, `about.html`, n.k.), kama ilivyoorodheshwa kwenye `sitemap.xml` yako. Hii inamaanisha:
- Kila link inafanya kazi ikifunguliwa moja kwa moja, kutoka popote
- Kila ukurasa una title na maelezo yake sahihi ya Google (SEO)
- Google haitapata makosa ya 404 kwenye Search Console
- Muonekano, mienendo (animations), FAQ accordion, hero slideshow, WhatsApp button — vyote vimebaki sawa kabisa

## Faili na folda zilizopo humu
| Faili/Folda | Kazi yake |
|---|---|
| `index.html`, `packages.html`, `about.html`, n.k. (kurasa 12 kwa jumla) | Kurasa halisi za tovuti |
| `assets/css/style.css` | Muundo/design wa tovuti (unatumika na kurasa zote — huwa cached na browser, hivyo tovuti inapakia haraka zaidi kati ya kurasa) |
| `assets/js/script.js` | Mienendo ya tovuti (FAQ accordion, hero slideshow, cookie banner, animations) |
| `assets/images/` | Picha zote 31 |
| `robots.txt`, `sitemap.xml` | Kwa ajili ya Google Search Console |
| `404.html` | Ukurasa wa mgeni akiingia link isiyopo |

## MUHIMU: Upakiaji (upload)
Pandisha **kila kitu kilichopo humu** kwenye root ya hosting yako (public_html au sawa na hilo) — faili zote za `.html` pamoja na folda nzima ya `assets/`:
```
public_html/
  index.html
  packages.html
  services.html
  about.html
  team.html
  testimonials.html
  blog.html
  faq.html
  contact.html
  what-to-pack-first-safari.html
  choosing-a-kilimanjaro-route.html
  great-migration-month-by-month.html
  robots.txt
  sitemap.xml
  404.html
  assets/
    css/style.css
    js/script.js
    images/ (faili 31)
```

## Kitu KIMOJA tu kilichobaki kabla ya live
**Domain**: Faili zote bado zina `https://www.nerasafaris.com` kama placeholder (kwenye meta tags, canonical links, robots.txt, sitemap.xml). Baada ya kununua domain yako halisi:
1. Tumia "Find & Replace" (mfano kwenye VS Code, Notepad++, au hata `sed`) kubadilisha `nerasafaris.com` kila mahali kwenye faili zote za `.html`, `robots.txt`, na `sitemap.xml` — badilisha na domain yako halisi
2. Hakikisha unaweka `www.` mbele ikiwa ndivyo utakavyotumia, au uondoe kama si hivyo

## Baada ya kufanya hivyo
1. Pandisha faili zote kwenye hosting yako (root folder ya domain)
2. Hakikisha `yourdomain.com/robots.txt` na `yourdomain.com/sitemap.xml` zinafunguka
3. Jaribu kufungua kila ukurasa moja kwa moja kwenye browser (mfano `yourdomain.com/packages.html`) kuhakikisha vyote vinafanya kazi
4. Submit sitemap kwenye Google Search Console
5. Subiri wiki 1-2 Google ianze kuonyesha site yako kwenye search results

## Taarifa nyingine muhimu (bado zipo, hazijabadilika)
- Namba ya simu/WhatsApp: +255 659 644 881
- Barua pepe: nerasafaris@gmail.com
- Anwani: 759 Azikiwe St, Dar es Salaam
- Google Analytics (GA4): G-2TJGENK5L8
- Social media: Instagram (@nera_safaristz), Facebook, WhatsApp, TikTok

Ukihitaji msaada zaidi (blog posts mpya, kubadilisha bei, kuongeza reviews, au kununua/kuunganisha domain), niambie tu.
